export const environment = {
  production: true,
  url_api: 'https://platzi-store.herokuapp.com',
  firebase: {
    apiKey: "AIzaSyB_NIHCdhlHPgAXyKfXUfd5aeUBrTl7ZmA",
    authDomain: "platzi-store-e8161.firebaseapp.com",
    databaseURL: "https://platzi-store-e8161.firebaseio.com",
    projectId: "platzi-store-e8161",
    storageBucket: "platzi-store-e8161.appspot.com",
    messagingSenderId: "977466761687",
    appId: "1:977466761687:web:d2ece6aeb7185df5932b92"
  }
};
